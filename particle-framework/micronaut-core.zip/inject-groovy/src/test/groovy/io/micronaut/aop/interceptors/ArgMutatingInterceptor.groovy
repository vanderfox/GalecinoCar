/*
 * Copyright 2017-2018 original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micronaut.aop.interceptors

import io.micronaut.aop.Interceptor
import io.micronaut.aop.InvocationContext

import javax.inject.Singleton

/**
 * @author Graeme Rocher
 * @since 1.0
 */
@Singleton
class ArgMutatingInterceptor implements Interceptor {

    @Override
    Object intercept(InvocationContext context) {
        Mutating m = context.getAnnotation(Mutating)
        def arg = context.getParameters().get(m.value())
        if(arg != null) {
            def value = arg.value
            if(value instanceof Number) {
                arg.setValue(((Number)value).intValue()*2)
            }
            else {
                arg.setValue("changed")
            }
        }
        return context.proceed()
    }
}