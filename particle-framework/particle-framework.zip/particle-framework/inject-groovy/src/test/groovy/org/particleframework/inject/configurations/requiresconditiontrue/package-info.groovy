@Configuration
@Requires(condition = TrueEnvCondition.class)
package org.particleframework.inject.configurations.requiresconditiontrue

import org.particleframework.context.annotation.Configuration
import org.particleframework.context.annotation.Requires
