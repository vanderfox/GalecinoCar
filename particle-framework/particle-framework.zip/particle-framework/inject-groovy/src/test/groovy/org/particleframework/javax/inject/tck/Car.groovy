package org.particleframework.javax.inject.tck

/**
 * Created by graemerocher on 12/05/2017.
 */
interface Car {

}

