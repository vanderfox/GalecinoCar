@Configuration
@Requires(configuration = "test")
package org.particleframework.inject.configurations.requiresconfig

import org.particleframework.context.annotation.Configuration
import org.particleframework.context.annotation.Requires
import org.particleframework.inject.configurations.NotABean

