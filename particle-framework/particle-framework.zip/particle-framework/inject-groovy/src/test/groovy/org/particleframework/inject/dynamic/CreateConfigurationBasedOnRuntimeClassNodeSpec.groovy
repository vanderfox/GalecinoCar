package org.particleframework.inject.dynamic

import spock.lang.Specification

/**
 * Created by graemerocher on 22/05/2017.
 */
class CreateConfigurationBasedOnRuntimeClassNodeSpec extends Specification {


}
