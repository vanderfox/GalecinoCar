package org.particleframework.inject.configurations

/**
 * Created by graemerocher on 19/05/2017.
 */
class NotABean {
}
