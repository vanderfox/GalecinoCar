package org.particleframework.inject.configurations.requiresconditiontrue;

import javax.inject.Singleton;

@Singleton
public class TrueBean {
}
