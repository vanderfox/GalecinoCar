package org.particleframework.inject.configurations.requirescondition2

import javax.inject.Singleton

/**
 * Created by graemerocher on 20/05/2017.
 */
@Singleton
class TrueLambdaBean {
}
