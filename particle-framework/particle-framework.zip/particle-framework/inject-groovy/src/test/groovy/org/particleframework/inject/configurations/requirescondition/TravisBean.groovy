package org.particleframework.inject.configurations.requirescondition

import javax.inject.Singleton

/**
 * Created by graemerocher on 20/05/2017.
 */
@Singleton
class TravisBean {
}
