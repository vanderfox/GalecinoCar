package org.particleframework.inject.configurations.requiressdk

import javax.inject.Singleton

/**
 * Created by graemerocher on 19/05/2017.
 */
@Singleton
class RequiresJava9 {
}
