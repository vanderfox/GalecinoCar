@Configuration
@Requires(condition = { ConditionContext context -> true })
package org.particleframework.inject.configurations.requirescondition2

import org.particleframework.context.annotation.Configuration
import org.particleframework.context.annotation.Requires
import org.particleframework.context.condition.ConditionContext
