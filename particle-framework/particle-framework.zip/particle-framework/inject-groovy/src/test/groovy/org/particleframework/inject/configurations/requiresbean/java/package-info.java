@Configuration
@Requires(beans = NotABean.class)
package org.particleframework.inject.configurations.requiresbean.java;

import org.particleframework.context.annotation.Configuration;
import org.particleframework.context.annotation.Requires;
import org.particleframework.inject.configurations.NotABean;
