@Configuration
@Requires(beans = NotABean.class)
package org.particleframework.inject.field;

import org.particleframework.context.annotation.Configuration;
import org.particleframework.context.annotation.Requires;
import org.particleframework.inject.configurations.NotABean;
