@Configuration
@Requires(property = "dataSource.url")
package org.particleframework.inject.configurations.requiresproperty

import org.particleframework.context.annotation.Configuration
import org.particleframework.context.annotation.Requires
