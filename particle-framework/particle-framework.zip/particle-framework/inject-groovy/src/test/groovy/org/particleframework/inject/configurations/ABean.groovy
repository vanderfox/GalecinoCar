package org.particleframework.inject.configurations

import javax.inject.Singleton

/**
 * Created by graemerocher on 19/05/2017.
 */
@Singleton
class ABean {
}
