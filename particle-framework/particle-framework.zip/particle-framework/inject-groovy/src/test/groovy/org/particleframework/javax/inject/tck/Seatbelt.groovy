package org.particleframework.javax.inject.tck

class Seatbelt {
}
