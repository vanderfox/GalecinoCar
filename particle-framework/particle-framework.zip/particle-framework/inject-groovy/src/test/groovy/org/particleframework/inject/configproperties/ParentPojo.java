package org.particleframework.inject.configproperties;

public class ParentPojo {

    private int port;

    public int getPort() {
        return this.port;
    }

    public void setPort(int port) {
        this.port = port;
    }
}
