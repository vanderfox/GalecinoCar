@Configuration
@Requires(beans = NotABean)
package org.particleframework.inject.configurations.requiresbean

import org.particleframework.context.annotation.Configuration
import org.particleframework.context.annotation.Requires
import org.particleframework.inject.configurations.NotABean

