package org.particleframework.javax.inject.tck

import javax.inject.Singleton

@Singleton
class FuelTank {

}