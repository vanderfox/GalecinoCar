@Configuration
@Requires(condition = TravisEnvCondition.class)
package org.particleframework.inject.configurations.requiresconditionfalse

import org.particleframework.context.annotation.Configuration
import org.particleframework.context.annotation.Requires
