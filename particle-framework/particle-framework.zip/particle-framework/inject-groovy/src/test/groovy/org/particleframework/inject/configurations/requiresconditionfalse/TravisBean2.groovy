package org.particleframework.inject.configurations.requiresconditionfalse

import javax.inject.Singleton

@Singleton
class TravisBean2 {
}
