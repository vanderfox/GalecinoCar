@Configuration
@Requires(sdk = Requires.Sdk.JAVA, version = "1.9.0")
package org.particleframework.inject.configurations.requiressdk

import org.particleframework.context.annotation.Configuration
import org.particleframework.context.annotation.Requires
