package org.particleframework.inject.configurations.requiresproperty

import javax.inject.Singleton

/**
 * Created by graemerocher on 15/06/2017.
 */
@Singleton
class RequiresProperty {
}
